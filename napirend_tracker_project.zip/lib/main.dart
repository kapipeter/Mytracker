import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(MyApp());
}

class Category {
  String id;
  String name;
  bool isTimeBased;
  int targetMinutes; // for time-based
  Category({required this.id, required this.name, required this.isTimeBased, this.targetMinutes = 0});
  factory Category.fromMap(Map m) => Category(
    id: m['id'], name: m['name'], isTimeBased: m['isTimeBased'], targetMinutes: m['targetMinutes'] ?? 0
  );
  Map toMap() => {'id': id, 'name': name, 'isTimeBased': isTimeBased, 'targetMinutes': targetMinutes};
}

class TimeEntry {
  String categoryId;
  int minutes;
  bool checked;
  String date; // yyyy-MM-dd
  TimeEntry({required this.categoryId, this.minutes = 0, this.checked = false, required this.date});
  factory TimeEntry.fromMap(Map m) => TimeEntry(
    categoryId: m['categoryId'], minutes: m['minutes'], checked: m['checked'], date: m['date']
  );
  Map toMap() => {'categoryId': categoryId, 'minutes': minutes, 'checked': checked, 'date': date};
}

class Transaction {
  String id;
  String date; // yyyy-MM-dd
  String category;
  double amount; // positive for income, negative for expense
  Transaction({required this.id, required this.date, required this.category, required this.amount});
  factory Transaction.fromMap(Map m) => Transaction(
    id: m['id'], date: m['date'], category: m['category'], amount: m['amount']
  );
  Map toMap() => {'id': id, 'date': date, 'category': category, 'amount': amount};
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  List<Category> categories = [];
  List<TimeEntry> entries = [];
  List<Transaction> transactions = [];
  List<String> top3 = ["", "", ""];
  final DateFormat fmt = DateFormat('yyyy-MM-dd');

  @override
  void initState(){
    super.initState();
    _loadAll();
  }

  Future<void> _loadAll() async {
    final sp = await SharedPreferences.getInstance();
    final catStr = sp.getString('categories');
    final entStr = sp.getString('entries');
    final txStr = sp.getString('transactions');
    final topStr = sp.getString('top3');
    if(catStr!=null){
      final arr = jsonDecode(catStr) as List;
      categories = arr.map((e)=>Category.fromMap(e)).toList();
    } else {
      // add some core categories
      categories = [
        Category(id: 'alvas', name: 'Alvás', isTimeBased: true, targetMinutes: 480),
        Category(id: 'sport', name: 'Sport', isTimeBased: true, targetMinutes: 30),
        Category(id: 'olasas', name: 'Olvasás', isTimeBased: true, targetMinutes: 20),
      ];
    }
    if(entStr!=null){
      final arr = jsonDecode(entStr) as List;
      entries = arr.map((e)=>TimeEntry.fromMap(e)).toList();
    }
    if(txStr!=null){
      final arr = jsonDecode(txStr) as List;
      transactions = arr.map((e)=>Transaction.fromMap(e)).toList();
    }
    if(topStr!=null){
      final arr = jsonDecode(topStr) as List;
      top3 = List<String>.from(arr);
    }
    setState((){});
  }

  Future<void> _saveAll() async {
    final sp = await SharedPreferences.getInstance();
    sp.setString('categories', jsonEncode(categories.map((e)=>e.toMap()).toList()));
    sp.setString('entries', jsonEncode(entries.map((e)=>e.toMap()).toList()));
    sp.setString('transactions', jsonEncode(transactions.map((e)=>e.toMap()).toList()));
    sp.setString('top3', jsonEncode(top3));
  }

  String today() => fmt.format(DateTime.now());

  int minutesForCategoryToday(String catId){
    final todayStr = today();
    final list = entries.where((e)=>e.categoryId==catId && e.date==todayStr);
    int sum=0;
    for(var e in list) sum += e.minutes;
    return sum;
  }

  bool checkedForCategoryToday(String catId){
    final todayStr = today();
    return entries.any((e)=>e.categoryId==catId && e.date==todayStr && e.checked);
  }

  double balanceForPeriod(DateTime from, DateTime to){
    double s=0;
    for(var t in transactions){
      final d = DateTime.parse(t.date);
      if(!d.isBefore(from) && !d.isAfter(to)) s += t.amount;
    }
    return s;
  }

  // UI helpers
  Future<void> _addCategoryDialog() async {
    final nameCtl = TextEditingController();
    bool isTime = true;
    int target = 30;
    await showDialog(context: context, builder: (_){
      return AlertDialog(
        title: Text('Új kategória'),
        content: StatefulBuilder(builder: (_, setSt){
          return Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: nameCtl, decoration: InputDecoration(labelText: 'Név')),
            Row(children:[
              Radio(value: true, groupValue: isTime, onChanged: (v){ setSt(()=> isTime = true); }),
              Text('Időmérős'),
              Radio(value: false, groupValue: isTime, onChanged: (v){ setSt(()=> isTime = false); }),
              Text('Pipálós'),
            ]),
            if(isTime) TextField(
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Napi cél (perc)'),
              onChanged: (v){ target = int.tryParse(v) ?? 30; },
            )
          ]);
        }),
        actions: [
          TextButton(onPressed: ()=>Navigator.pop(context), child: Text('Mégse')),
          ElevatedButton(onPressed: (){
            final id = DateTime.now().millisecondsSinceEpoch.toString();
            categories.add(Category(id: id, name: nameCtl.text.isEmpty ? 'Új' : nameCtl.text, isTimeBased: isTime, targetMinutes: target));
            _saveAll();
            setState(()=>{});
            Navigator.pop(context);
          }, child: Text('Mentés'))
        ],
      );
    });
  }

  Future<void> _addEntryDialog(Category cat) async {
    final minutesCtl = TextEditingController(text: '0');
    bool markChecked = false;
    await showDialog(context: context, builder: (_){
      return AlertDialog(
        title: Text('Rögzítés: ${cat.name}'),
        content: StatefulBuilder(builder: (_, setSt){
          return Column(mainAxisSize: MainAxisSize.min, children: [
            if(cat.isTimeBased)
              TextField(controller: minutesCtl, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'Perc hozzáadása')),
            if(!cat.isTimeBased)
              CheckboxListTile(value: markChecked, onChanged: (v){ setSt(()=> markChecked = v ?? false); }, title: Text('Kész')),
          ]);
        }),
        actions: [
          TextButton(onPressed: ()=>Navigator.pop(context), child: Text('Mégse')),
          ElevatedButton(onPressed: (){
            final d = today();
            if(cat.isTimeBased){
              final m = int.tryParse(minutesCtl.text) ?? 0;
              entries.add(TimeEntry(categoryId: cat.id, minutes: m, checked: false, date: d));
            } else {
              entries.add(TimeEntry(categoryId: cat.id, minutes: 0, checked: markChecked, date: d));
            }
            _saveAll();
            setState(()=>{});
            Navigator.pop(context);
          }, child: Text('Mentés'))
        ],
      );
    });
  }

  Future<void> _addTransactionDialog() async {
    final amtCtl = TextEditingController();
    final catCtl = TextEditingController();
    bool isIncome = false;
    await showDialog(context: context, builder: (_){
      return AlertDialog(
        title: Text('Új tranzakció'),
        content: StatefulBuilder(builder: (_, setSt){
          return Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: catCtl, decoration: InputDecoration(labelText: 'Kategória')),
            TextField(controller: amtCtl, keyboardType: TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: 'Összeg (EUR)')),
            Row(children: [Checkbox(value: isIncome, onChanged: (v){ setSt(()=> isIncome = v ?? false); }), Text('Bevétel (ha be van pipálva, pozitív)')])
          ]);
        }),
        actions: [
          TextButton(onPressed: ()=>Navigator.pop(context), child: Text('Mégse')),
          ElevatedButton(onPressed: (){
            final d = today();
            final amt = double.tryParse(amtCtl.text.replaceAll(',', '.')) ?? 0.0;
            final a = isIncome ? amt.abs() : -amt.abs();
            final id = DateTime.now().millisecondsSinceEpoch.toString();
            transactions.add(Transaction(id: id, date: d, category: catCtl.text.isEmpty ? 'Egyéb' : catCtl.text, amount: a));
            _saveAll();
            setState(()=>{});
            Navigator.pop(context);
          }, child: Text('Mentés'))
        ],
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final todayStr = today();
    final todayEntries = entries.where((e)=>e.date==todayStr).toList();
    final income = transactions.where((t)=> t.amount>0 && t.date==todayStr).fold(0.0, (p,e)=>p+e.amount);
    final expense = transactions.where((t)=> t.amount<0 && t.date==todayStr).fold(0.0, (p,e)=>p+e.amount);
    return MaterialApp(
      title: 'Napirend Tracker',
      home: Scaffold(
        appBar: AppBar(title: Text('Napirend'), centerTitle: true),
        body: Padding(
          padding: EdgeInsets.all(12),
          child: SingleChildScrollView(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Mai top 3 fókusz', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              Card(child: Padding(padding: EdgeInsets.all(8), child: Column(
                children: List.generate(3, (i){
                  return Row(children: [
                    Checkbox(value: top3[i].isNotEmpty && checkedForTop(i), onChanged: (v){ _toggleTopChecked(i); }),
                    Expanded(child: TextFormField(initialValue: top3[i], decoration: InputDecoration(hintText: 'Fókusz ${i+1}'), onChanged: (val){ top3[i]=val; _saveAll(); })),
                  ]);
                })
              ))),
              SizedBox(height: 12),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('Napi mérföldkövek', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ElevatedButton(onPressed: _addCategoryDialog, child: Text('Új kategória'))
              ]),
              Column(children: categories.map((c){
                final mins = minutesForCategoryToday(c.id);
                final checked = checkedForCategoryToday(c.id);
                return Card(child: ListTile(
                  leading: Icon(c.isTimeBased ? Icons.timer : Icons.check_box),
                  title: Text(c.name),
                  subtitle: c.isTimeBased ? Text('${mins} / ${c.targetMinutes} perc') : Text(checked ? 'Kész' : 'Nincs kész'),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(icon: Icon(Icons.add), onPressed: ()=>_addEntryDialog(c)),
                    IconButton(icon: Icon(Icons.delete), onPressed: (){
                      setState(()=> categories.removeWhere((x)=>x.id==c.id));
                      _saveAll();
                    })
                  ]),
                ));
              }).toList()),
              SizedBox(height: 12),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('Pénzügyek', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ElevatedButton(onPressed: _addTransactionDialog, child: Text('Új'))
              ]),
              Card(child: Padding(padding: EdgeInsets.all(8), child: Column(children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Bevétel (ma)'), Text('${income.toStringAsFixed(2)} €')]),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Kiadás (ma)'), Text('${expense.toStringAsFixed(2)} €')]),
              ]))),
              SizedBox(height: 12),
              Text('Összesítés', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              Card(child: Padding(padding: EdgeInsets.all(8), child: Column(children: [
                Row(children: [Icon(Icons.access_time), SizedBox(width:8), Text('Összes idő ma: '), Spacer(), Text('${todayEntries.fold(0,(p,e)=>p+e.minutes)} perc')]),
                Row(children: [Icon(Icons.check), SizedBox(width:8), Text('Teljesített pipák ma: '), Spacer(), Text('${todayEntries.where((e)=>e.checked).length}')]),
                Row(children: [Icon(Icons.account_balance_wallet), SizedBox(width:8), Text('Egyenleg ma: '), Spacer(), Text('${(income+expense).toStringAsFixed(2)} €')]),
              ]))),
            ]),
          ),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () async {
            // quick actions: open add dialogs
            showModalBottomSheet(context: context, builder: (_){
              return SafeArea(child: Wrap(children: [
                ListTile(leading: Icon(Icons.add_task), title: Text('Új kategória'), onTap: (){ Navigator.pop(context); _addCategoryDialog(); }),
                ListTile(leading: Icon(Icons.payment), title: Text('Új tranzakció'), onTap: (){ Navigator.pop(context); _addTransactionDialog(); }),
              ]));
            });
          },
          child: Icon(Icons.add),
        ),
      ),
    );
  }

  // helpers for top3 checks: store as entries with special category 'topX'
  bool checkedForTop(int i){
    final d = today();
    final id = "top_${i}_\$${d}";
    return entries.any((e)=> e.categoryId==id && e.date==d && e.checked);
  }
  void _toggleTopChecked(int i){
    final d = today();
    final id = "top_${i}_\$${d}";
    final existing = entries.where((e)=> e.categoryId==id && e.date==d).toList();
    if(existing.isNotEmpty){
      // toggle
      final e = existing.first;
      e.checked = !e.checked;
    } else {
      entries.add(TimeEntry(categoryId: id, minutes: 0, checked: true, date: d));
    }
    _saveAll();
    setState(()=>{});
  }
}
