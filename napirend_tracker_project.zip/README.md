# Napirend Tracker — MVP

Ez egy egyszerű Flutter alapú MVP az apphoz. Tartalmaz:
- `lib/main.dart` — az alkalmazás kódja (magyar nyelvű UI)
- `pubspec.yaml` — függőségek
- `.github/workflows/flutter-build.yml` — GitHub Actions workflow az APK építéséhez (automatikus build, artifact letöltéssel)

## Hogyan kapd meg az APK-t (lépések GitHubbal)

1. Hozz létre egy új repository-t (már megtetted).
2. Töltsd fel ezt a projekt ZIP-et a repo gyökerébe (vagy húzd fel fájlokat).
3. Commit/push után menj a GitHub repo `Actions` fülére.
4. Válaszd ki a `Build APK` workflow-t, és indítsd el (vagy várd meg, hogy futjon push után).
5. A workflow lefutása után az artifactoknál találod az `napirend-tracker-apk` artifactot — onnan letöltheted az `app-release.apk` fájlt.
6. Telepítés a Samsung A56 készülékre: engedélyezd az ismeretlen forrásból történő telepítést, majd másold át az APK-t a telefonra és megnyitva telepítsd.

## Megjegyzések
- Az app helyi tárolást használ a `shared_preferences` segítségével.
- Alapértelmezett valuta EUR.
- A GitHub Actions workflow egy `flutter create .` lépést tartalmaz arra az esetre, ha hiányozna a platform könyvtár (így CI generálja azt).
- Ha szeretnéd, hogy feltöltjek egy ZIP-et készen a repo-dba, mondd meg a repo nevét és GitHub felhasználóneved — megmutatom a pontos feltöltési lépéseket.

